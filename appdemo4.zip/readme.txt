DB AppMaker 4 Demo Project

***IMPORTANT: Make sure your Windows (and Mac) is prepped. Read the following in the help file first:
- Preparing Windows for Android App Development
- Preparing Mac for iOS App Development

1. Install all the system requirements first (see above),
2. Install DB AppMaker,
3. Unzip the demo archive to any folder (referred as the "unzipped folder" below),
4. Create a MySQL database (e.g. named as "demo4") using the demo4.sql
5. Double click demo4.amp to open the project,
6. Update the project settings: 
- Update the connection info in the "Database" tab to your database connection info, click "Tools" -> "Synchronize" to update the project with the database,
- Click "Config" -> "Platform" tab, update the icon and splash screen images as the corresponding images in the unzipped folder,
7. Click on the "Generate" tab, change the project folder to where you want to output the generated files,
8. Change the Platform" to "Android" and set the Ionic CLI command to "serve", (you can change to "iOS" later)
9. Click the "Generate" button,
10. Configure IIS to support the API application (if you have not installed IIS, read set up IIS web server in help file):
- Right click on Default Web Site and click Add Application, set Alias to "api" and select folder to the "api" subfolder of the project folder
- Make sure that your web site is enabled for PHP
- Create the "files" subfolder under the "api" subfolder and copy the "*.jpg" files to that folder
- Set Read Permission for the "api" folder and Read/Write Permission for the "api/files" folder
- To verify the API application is running, run the following url in the browser and you should get the json response:
http://localhost/api/?object=products  
11. Run the app in browser.